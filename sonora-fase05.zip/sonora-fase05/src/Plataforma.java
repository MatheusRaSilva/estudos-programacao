import java.util.ArrayList;

public class Plataforma {

    private static final int CAPACIDADE_MAXIMA = 500;

    // Acervo unico: guarda musicas e podcasts (qualquer Conteudo).
    private ArrayList<Conteudo> acervo;
    private ArrayList<Usuario> usuarios;
    private ArrayList<Anuncio> anuncios;

    public Plataforma() {
        this.acervo = new ArrayList<Conteudo>();
        this.usuarios = new ArrayList<Usuario>();
        this.anuncios = new ArrayList<Anuncio>();
    }

    public boolean cadastrarConteudo(Conteudo conteudo) {
        if (conteudo == null || acervo.size() >= CAPACIDADE_MAXIMA) {
            return false;
        }
        acervo.add(conteudo);
        return true;
    }

    public boolean cadastrarUsuario(Usuario usuario) {
        if (usuario == null || usuarios.size() >= CAPACIDADE_MAXIMA) {
            return false;
        }
        usuarios.add(usuario);
        return true;
    }

    public boolean cadastrarAnuncio(Anuncio anuncio) {
        if (anuncio == null) {
            return false;
        }
        anuncios.add(anuncio);
        return true;
    }

    public Conteudo buscarMusicaPorId(int id) {
        for (Conteudo conteudo : acervo) {
            if (conteudo.getId() == id) {
                return conteudo;
            }
        }
        return null;
    }

    public Conteudo buscarMusica(String titulo) {
        for (Conteudo conteudo : acervo) {
            if (conteudo.getTitulo().equalsIgnoreCase(titulo)) {
                return conteudo;
            }
        }
        return null;
    }

    public Usuario buscarUsuarioPorId(int id) {
        for (Usuario usuario : usuarios) {
            if (usuario.getId() == id) {
                return usuario;
            }
        }
        return null;
    }

    public int getTotalMusicas() {
        return acervo.size();
    }

    public int getTotalUsuarios() {
        return usuarios.size();
    }

    // B2/D1: um unico laco sobre Faturavel, sem instanceof e sem cast.
    // Planos e anuncios entram na mesma lista porque ambos prometem calcularMensalidade().
    public double calcularReceitaMensal() {
        ArrayList<Faturavel> cobrancas = new ArrayList<Faturavel>();
        for (Usuario usuario : usuarios) {
            cobrancas.add(usuario.getPlano());
        }
        for (Anuncio anuncio : anuncios) {
            cobrancas.add(anuncio);
        }

        double total = 0;
        for (Faturavel cobranca : cobrancas) {
            total += cobranca.calcularMensalidade();
        }
        return total;
    }

    // B3: aqui o instanceof com downcasting e legitimo, porque getApresentador()
    // so existe em Podcast e o tipo estatico dos itens do acervo e Conteudo.
    public void listarEpisodiosDe(String apresentador) {
        boolean achou = false;
        for (Conteudo conteudo : acervo) {
            if (conteudo instanceof Podcast) {
                Podcast podcast = (Podcast) conteudo;
                if (podcast.getApresentador().equalsIgnoreCase(apresentador)) {
                    System.out.println(podcast);
                    achou = true;
                }
            }
        }
        if (!achou) {
            System.out.println("Nenhum episodio encontrado para o apresentador \"" + apresentador + "\".");
        }
    }

    // D2: monta uma fila de Reproduzivel (itens + anuncios) e toca tudo.
    // A decisao de usar anuncios vem de temAnuncios(), sem perguntar o tipo do plano.
    // Um anuncio entra depois de cada 2 itens da playlist, em rodizio.
    public void tocarPlaylist(Usuario ouvinte, Playlist playlist) {
        if (ouvinte == null) {
            throw new IllegalArgumentException("Ouvinte nulo: informe um usuario.");
        }
        if (playlist == null) {
            throw new IllegalArgumentException("Playlist nula: informe uma playlist.");
        }

        boolean comAnuncios = ouvinte.getPlano().temAnuncios() && !anuncios.isEmpty();

        ArrayList<Reproduzivel> fila = new ArrayList<Reproduzivel>();
        int proximoAnuncio = 0;
        for (int i = 0; i < playlist.getQuantidade(); i++) {
            fila.add(playlist.getNaPosicao(i));
            if (comAnuncios && (i + 1) % 2 == 0) {
                fila.add(anuncios.get(proximoAnuncio));
                proximoAnuncio = (proximoAnuncio + 1) % anuncios.size();
            }
        }

        for (Reproduzivel item : fila) {
            System.out.println("[" + item.getDuracaoFormatada() + "]");
            item.reproduzir();
        }
    }
}
