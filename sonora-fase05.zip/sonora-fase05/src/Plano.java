// Plano e abstrata e implementa Faturavel sem implementar calcularMensalidade():
// a obrigacao desce para as subclasses concretas.
public abstract class Plano implements Faturavel {

    private final String nome;

    protected Plano(String nome) {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome do plano invalido: nao pode ser vazio.");
        }
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public abstract boolean temAnuncios();

    public String resumo() {
        return nome + " - R$ " + String.format("%.2f", calcularMensalidade())
                + (temAnuncios() ? " (com anuncios)" : " (sem anuncios)");
    }
}
