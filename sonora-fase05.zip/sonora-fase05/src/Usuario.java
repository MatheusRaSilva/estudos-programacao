import java.util.ArrayList;

public class Usuario {

    private static int contadorId = 0;

    private final int id;
    private String nome;
    private String email;
    private Plano plano;

    // Coleção da associação reflexiva: os usuarios que ESTE usuario segue.
    private ArrayList<Usuario> seguindo;

    // Sem plano informado, o usuario comeca no plano gratuito.
    public Usuario(String nome, String email) {
        this(nome, email, new PlanoGratuito());
    }

    public Usuario(String nome, String email, Plano plano) {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome invalido: nao pode ser vazio.");
        }
        if (email == null || email.trim().isEmpty() || !email.contains("@")) {
            throw new IllegalArgumentException(
                    "Email invalido: \"" + email + "\". O email precisa conter '@'.");
        }
        if (plano == null) {
            throw new IllegalArgumentException("Plano invalido: nao pode ser nulo.");
        }
        contadorId++;
        this.id = contadorId;
        this.nome = nome;
        this.email = email;
        this.plano = plano;
        this.seguindo = new ArrayList<Usuario>();
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public Plano getPlano() {
        return plano;
    }

    public boolean seguir(Usuario outro) {
        if (outro == null) {
            // Passar usuario nulo e uso indevido do metodo: vira excecao.
            throw new IllegalArgumentException("Nao e possivel seguir um usuario nulo.");
        }
        if (outro == this) {
            // Tentar seguir a si mesmo tambem e uso indevido de quem chamou.
            throw new IllegalArgumentException("Um usuario nao pode seguir a si mesmo.");
        }
        if (seguindo.contains(outro)) {
            // Ja seguir alguem e situacao normal de operacao: sinalizada por retorno.
            return false;
        }
        seguindo.add(outro);
        return true;
    }

    public boolean deixarDeSeguir(Usuario outro) {
        if (outro == null) {
            throw new IllegalArgumentException("Nao e possivel deixar de seguir um usuario nulo.");
        }
        // remove() devolve false quando o usuario nao estava na lista (fluxo normal).
        return seguindo.remove(outro);
    }

    public int getQuantidadeSeguindo() {
        return seguindo.size();
    }

    public ArrayList<Usuario> getSeguindo() {
        return seguindo;
    }

    @Override
    public String toString() {
        return "#" + id + " - " + nome + " (" + email + ")";
    }
}
