public class PlanoPremium extends Plano {

    private static final double MENSALIDADE = 21.90;

    public PlanoPremium() {
        super("Premium");
    }

    @Override
    public double calcularMensalidade() {
        return MENSALIDADE;
    }

    @Override
    public boolean temAnuncios() {
        return false;
    }
}
