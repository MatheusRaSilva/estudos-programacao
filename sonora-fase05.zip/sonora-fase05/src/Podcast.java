public class Podcast extends Conteudo {

    private final String apresentador;

    public Podcast(String titulo, String apresentador, int duracaoSegundos) {
        // Mesmo cuidado da Musica: valida antes do super() para nao gastar id a toa.
        super(titulo, duracaoAposValidarApresentador(apresentador, duracaoSegundos));
        this.apresentador = apresentador;
    }

    private static int duracaoAposValidarApresentador(String apresentador, int duracaoSegundos) {
        exigirTexto(apresentador, "Apresentador invalido: nao pode ser vazio.");
        return duracaoSegundos;
    }

    public String getApresentador() {
        return apresentador;
    }

    @Override
    public String getCreditos() {
        return "Apresentador: " + apresentador;
    }
}
