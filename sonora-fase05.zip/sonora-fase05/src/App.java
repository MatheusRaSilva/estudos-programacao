import java.util.ArrayList;
import java.util.Scanner;

public class App {

    private static Scanner scanner = new Scanner(System.in);
    private static Plataforma plataforma = new Plataforma();

    // Guarda as playlists criadas na sessao, para poder usa-las de novo depois
    // (nas opcoes 8 e 9). Agora e um ArrayList: cresce sozinho, sem limite fixo.
    private static ArrayList<Playlist> playlists = new ArrayList<Playlist>();

    public static void main(String[] args) {
        plataforma.cadastrarConteudo(new Musica("Bohemian Rhapsody", "Queen", 354));
        plataforma.cadastrarConteudo(new Musica("Blowin' in the Wind", "Bob Dylan", 65));
        plataforma.cadastrarConteudo(new Musica("Aguas de Marco", "Elis Regina", 600));

        // B3: tipo estatico x tipo dinamico.
        // Tipo estatico de c: Conteudo (o que esta escrito na declaracao; o compilador so
        //                     enxerga os membros de Conteudo).
        // Tipo dinamico de c: Podcast (o objeto que de fato foi criado; decide qual
        //                     getCreditos() roda em tempo de execucao).
        Conteudo c = new Podcast("Introducao a POO", "Andre", 1800);
        // c.getApresentador();
        // ^ nao compila: getApresentador() existe so em Podcast, e o compilador confere os
        //   membros pelo tipo ESTATICO (Conteudo). Mesmo o objeto sendo um Podcast, Conteudo
        //   nao declara esse metodo. Seria preciso instanceof + cast para Podcast.
        plataforma.cadastrarConteudo(c);
        plataforma.cadastrarConteudo(new Podcast("Heranca na pratica", "Andre", 2100));

        int opcao;
        do {
            System.out.println();
            System.out.println("=== Sonora ===");
            System.out.println("1 - Cadastrar musica manualmente");
            System.out.println("2 - Cadastrar usuario");
            System.out.println("3 - Criar playlist e adicionar musicas");
            System.out.println("4 - Buscar musica por id");
            System.out.println("5 - Buscar musica por titulo");
            System.out.println("6 - Reproduzir uma musica (por id)");
            System.out.println("7 - Listar acervo");
            System.out.println("8 - Reproduzir musica de uma playlist (por posicao)");
            System.out.println("9 - Remover musica de uma playlist (por posicao)");
            System.out.println("10 - Seguir usuario");
            System.out.println("11 - Deixar de seguir usuario");
            System.out.println("12 - Listar quem um usuario segue");
            System.out.println("13 - Cadastrar anuncio");
            System.out.println("14 - Adicionar podcast a uma playlist");
            System.out.println("15 - Tocar playlist para um usuario");
            System.out.println("16 - Listar episodios de um apresentador");
            System.out.println("17 - Exibir receita mensal da plataforma");
            System.out.println("0 - Sair");
            System.out.print("Opcao: ");

            // Leitura segura: converte o texto digitado com parseInt dentro de um try.
            // Se vier algo que nao e numero, avisa e volta pro menu sem derrubar o programa.
            try {
                opcao = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Valor invalido. Digite um numero.");
                opcao = -1;
            }

            switch (opcao) {
                case 1:
                    cadastrarMusica();
                    break;
                case 2:
                    cadastrarUsuario();
                    break;
                case 3:
                    criarPlaylist();
                    break;
                case 4:
                    buscarPorId();
                    break;
                case 5:
                    buscarPorTitulo();
                    break;
                case 6:
                    reproduzir();
                    break;
                case 7:
                    listarAcervo();
                    break;
                case 8:
                    reproduzirDaPlaylist();
                    break;
                case 9:
                    removerDaPlaylist();
                    break;
                case 10:
                    seguirUsuario();
                    break;
                case 11:
                    deixarDeSeguirUsuario();
                    break;
                case 12:
                    listarSeguindo();
                    break;
                case 13:
                    cadastrarAnuncio();
                    break;
                case 14:
                    adicionarPodcastNaPlaylist();
                    break;
                case 15:
                    tocarPlaylistParaUsuario();
                    break;
                case 16:
                    listarEpisodios();
                    break;
                case 17:
                    exibirReceitaMensal();
                    break;
                case 0:
                    break;
                case -1:
                    // entrada invalida ja foi avisada acima, nao precisa de outra mensagem
                    break;
                default:
                    System.out.println("Opcao invalida.");
            }
        } while (opcao != 0);
    }

    private static void cadastrarMusica() {
        System.out.print("Titulo: ");
        String titulo = scanner.nextLine();
        System.out.print("Artista: ");
        String artista = scanner.nextLine();
        System.out.print("Duracao (segundos): ");
        String duracaoTexto = scanner.nextLine();

        try {
            int duracao = Integer.parseInt(duracaoTexto);
            Musica musica = new Musica(titulo, artista, duracao);
            boolean ok = plataforma.cadastrarConteudo(musica);
            if (ok) {
                System.out.println("Cadastrada com id " + musica.getId());
            } else {
                System.out.println("Nao foi possivel cadastrar (acervo cheio).");
            }
        } catch (NumberFormatException e) {
            System.out.println("Duracao invalida: informe um numero inteiro.");
        } catch (IllegalArgumentException e) {
            System.out.println("Nao foi possivel cadastrar: " + e.getMessage());
        } finally {
            System.out.println("--- operacao de cadastro de musica finalizada ---");
        }
    }

    private static void cadastrarUsuario() {
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Plano (1 = Gratuito, 2 = Premium): ");
        String planoTexto = scanner.nextLine();

        try {
            Plano plano;
            int opcaoPlano = Integer.parseInt(planoTexto);
            if (opcaoPlano == 1) {
                plano = new PlanoGratuito();
            } else if (opcaoPlano == 2) {
                plano = new PlanoPremium();
            } else {
                throw new IllegalArgumentException("Plano invalido: escolha 1 ou 2.");
            }
            Usuario usuario = new Usuario(nome, email, plano);
            boolean ok = plataforma.cadastrarUsuario(usuario);
            if (ok) {
                System.out.println("Cadastrado com id " + usuario.getId() + " - " + plano.resumo());
            } else {
                System.out.println("Nao foi possivel cadastrar (limite atingido).");
            }
        } catch (NumberFormatException e) {
            System.out.println("Plano invalido: informe 1 ou 2.");
        } catch (IllegalArgumentException e) {
            System.out.println("Nao foi possivel cadastrar: " + e.getMessage());
        }
    }

    private static void criarPlaylist() {
        System.out.print("Nome da playlist: ");
        String nome = scanner.nextLine();
        System.out.print("Id do usuario dono (ja cadastrado): ");
        String idTexto = scanner.nextLine();

        Playlist playlist;
        try {
            int idDono = Integer.parseInt(idTexto);
            Usuario dono = plataforma.buscarUsuarioPorId(idDono);
            if (dono == null) {
                System.out.println("Usuario nao encontrado. Cadastre o usuario primeiro (opcao 2).");
                return;
            }
            playlist = new Playlist(nome, dono);
        } catch (NumberFormatException e) {
            System.out.println("Id do usuario precisa ser um numero.");
            return;
        } catch (IllegalArgumentException e) {
            System.out.println("Nao foi possivel criar a playlist: " + e.getMessage());
            return;
        }

        while (true) {
            System.out.print("Id da musica a adicionar (0 para parar): ");
            int id;
            try {
                id = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Id invalido, informe um numero.");
                continue;
            }
            if (id == 0) {
                break;
            }
            Conteudo musica = plataforma.buscarMusicaPorId(id);
            if (musica == null) {
                System.out.println("Musica nao encontrada.");
                continue;
            }
            boolean ok = playlist.adicionar(musica);
            System.out.println(ok ? "Adicionada." : "Playlist cheia.");
        }

        System.out.println("Quantidade: " + playlist.getQuantidade());
        System.out.println("Duracao total (s): " + playlist.getDuracaoTotalSegundos());

        playlists.add(playlist);
        System.out.println("Playlist guardada no indice " + (playlists.size() - 1)
                + " (use esse indice nas opcoes 8 e 9).");
    }

    private static void buscarPorId() {
        System.out.print("Id: ");
        try {
            int id = Integer.parseInt(scanner.nextLine());
            Conteudo musica = plataforma.buscarMusicaPorId(id);
            System.out.println(musica == null ? "Nao encontrada." : musica);
        } catch (NumberFormatException e) {
            System.out.println("Id invalido, informe um numero.");
        }
    }

    private static void buscarPorTitulo() {
        System.out.print("Titulo: ");
        String titulo = scanner.nextLine();
        Conteudo musica = plataforma.buscarMusica(titulo);
        System.out.println(musica == null ? "Nao encontrada." : musica);
    }

    private static void reproduzir() {
        System.out.print("Id da musica: ");
        try {
            int id = Integer.parseInt(scanner.nextLine());
            Conteudo musica = plataforma.buscarMusicaPorId(id);
            if (musica == null) {
                System.out.println("Nao encontrada.");
                return;
            }
            musica.reproduzir();
            System.out.println("Reproducoes: " + musica.getReproducoes());
        } catch (NumberFormatException e) {
            System.out.println("Id invalido, informe um numero.");
        }
    }

    private static void listarAcervo() {
        for (int id = 1; id <= plataforma.getTotalMusicas(); id++) {
            System.out.println(plataforma.buscarMusicaPorId(id));
        }
    }

    // Bloco com MULTIPLOS catch: trata separadamente o texto que nao e numero
    // (NumberFormatException) e a posicao fora do intervalo (IndexOutOfBoundsException),
    // do mais especifico para o mais generico.
    private static void reproduzirDaPlaylist() {
        try {
            System.out.print("Indice da playlist (veja o numero mostrado ao criar): ");
            int indicePlaylist = Integer.parseInt(scanner.nextLine());
            Playlist playlist = obterPlaylist(indicePlaylist);

            System.out.print("Posicao da musica na playlist: ");
            int posicao = Integer.parseInt(scanner.nextLine());
            Conteudo musica = playlist.getNaPosicao(posicao);

            musica.reproduzir();
            System.out.println("Tocando: " + musica.getTitulo()
                    + " (reproducoes: " + musica.getReproducoes() + ")");
        } catch (NumberFormatException e) {
            System.out.println("A posicao/indice precisa ser um numero.");
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Nao foi possivel completar: " + e.getMessage());
        }
    }

    // Segundo bloco com multiplos catch + finally, para exercitar removerNaPosicao().
    private static void removerDaPlaylist() {
        try {
            System.out.print("Indice da playlist (veja o numero mostrado ao criar): ");
            int indicePlaylist = Integer.parseInt(scanner.nextLine());
            Playlist playlist = obterPlaylist(indicePlaylist);

            System.out.print("Posicao a remover: ");
            int posicao = Integer.parseInt(scanner.nextLine());
            playlist.removerNaPosicao(posicao);

            System.out.println("Removida. Quantidade atual: " + playlist.getQuantidade());
        } catch (NumberFormatException e) {
            System.out.println("A posicao/indice precisa ser um numero.");
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Nao foi possivel completar: " + e.getMessage());
        } finally {
            System.out.println("--- operacao de remocao finalizada ---");
        }
    }

    private static void seguirUsuario() {
        try {
            System.out.print("Id do usuario que vai seguir: ");
            Usuario seguidor = plataforma.buscarUsuarioPorId(Integer.parseInt(scanner.nextLine()));
            System.out.print("Id do usuario a ser seguido: ");
            Usuario seguido = plataforma.buscarUsuarioPorId(Integer.parseInt(scanner.nextLine()));

            if (seguidor == null || seguido == null) {
                System.out.println("Usuario nao encontrado. Cadastre o usuario primeiro (opcao 2).");
                return;
            }

            boolean ok = seguidor.seguir(seguido);
            if (ok) {
                System.out.println(seguidor.getNome() + " agora segue " + seguido.getNome()
                        + ". Total seguindo: " + seguidor.getQuantidadeSeguindo());
            } else {
                System.out.println(seguidor.getNome() + " ja seguia " + seguido.getNome() + ".");
            }
        } catch (NumberFormatException e) {
            System.out.println("Id invalido, informe um numero.");
        } catch (IllegalArgumentException e) {
            System.out.println("Nao foi possivel seguir: " + e.getMessage());
        }
    }

    private static void deixarDeSeguirUsuario() {
        try {
            System.out.print("Id do usuario que vai deixar de seguir: ");
            Usuario seguidor = plataforma.buscarUsuarioPorId(Integer.parseInt(scanner.nextLine()));
            System.out.print("Id do usuario a deixar de seguir: ");
            Usuario seguido = plataforma.buscarUsuarioPorId(Integer.parseInt(scanner.nextLine()));

            if (seguidor == null || seguido == null) {
                System.out.println("Usuario nao encontrado. Cadastre o usuario primeiro (opcao 2).");
                return;
            }

            boolean ok = seguidor.deixarDeSeguir(seguido);
            if (ok) {
                System.out.println(seguidor.getNome() + " deixou de seguir " + seguido.getNome()
                        + ". Total seguindo: " + seguidor.getQuantidadeSeguindo());
            } else {
                System.out.println(seguidor.getNome() + " nao seguia " + seguido.getNome() + ".");
            }
        } catch (NumberFormatException e) {
            System.out.println("Id invalido, informe um numero.");
        } catch (IllegalArgumentException e) {
            System.out.println("Nao foi possivel deixar de seguir: " + e.getMessage());
        }
    }

    private static void listarSeguindo() {
        try {
            System.out.print("Id do usuario: ");
            Usuario usuario = plataforma.buscarUsuarioPorId(Integer.parseInt(scanner.nextLine()));

            if (usuario == null) {
                System.out.println("Usuario nao encontrado. Cadastre o usuario primeiro (opcao 2).");
                return;
            }

            System.out.println(usuario.getNome() + " segue " + usuario.getQuantidadeSeguindo()
                    + " usuario(s):");
            for (Usuario seguido : usuario.getSeguindo()) {
                System.out.println("  " + seguido);
            }
        } catch (NumberFormatException e) {
            System.out.println("Id invalido, informe um numero.");
        }
    }

    private static void cadastrarAnuncio() {
        System.out.print("Anunciante: ");
        String anunciante = scanner.nextLine();
        System.out.print("Titulo: ");
        String titulo = scanner.nextLine();
        System.out.print("Duracao (segundos): ");
        String duracaoTexto = scanner.nextLine();
        System.out.print("Valor por mil impressoes: ");
        String valorTexto = scanner.nextLine();

        try {
            int duracao = Integer.parseInt(duracaoTexto);
            double valor = Double.parseDouble(valorTexto.replace(',', '.'));
            Anuncio anuncio = new Anuncio(anunciante, titulo, duracao, valor);
            plataforma.cadastrarAnuncio(anuncio);
            System.out.println("Anuncio cadastrado: " + anuncio.getTitulo());
        } catch (NumberFormatException e) {
            System.out.println("Duracao e valor precisam ser numeros.");
        } catch (IllegalArgumentException e) {
            System.out.println("Nao foi possivel cadastrar o anuncio: " + e.getMessage());
        }
    }

    private static void adicionarPodcastNaPlaylist() {
        try {
            System.out.print("Indice da playlist (veja o numero mostrado ao criar): ");
            Playlist playlist = obterPlaylist(Integer.parseInt(scanner.nextLine()));

            System.out.print("Id do podcast: ");
            Conteudo conteudo = plataforma.buscarMusicaPorId(Integer.parseInt(scanner.nextLine()));

            if (conteudo == null) {
                System.out.println("Conteudo nao encontrado.");
                return;
            }
            if (!(conteudo instanceof Podcast)) {
                System.out.println("O id informado nao e de um podcast.");
                return;
            }
            boolean ok = playlist.adicionar(conteudo);
            System.out.println(ok ? "Podcast adicionado." : "Playlist cheia.");
        } catch (NumberFormatException e) {
            System.out.println("O indice/id precisa ser um numero.");
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Nao foi possivel completar: " + e.getMessage());
        }
    }

    private static void tocarPlaylistParaUsuario() {
        try {
            System.out.print("Indice da playlist (veja o numero mostrado ao criar): ");
            Playlist playlist = obterPlaylist(Integer.parseInt(scanner.nextLine()));

            System.out.print("Id do usuario ouvinte: ");
            Usuario ouvinte = plataforma.buscarUsuarioPorId(Integer.parseInt(scanner.nextLine()));
            if (ouvinte == null) {
                System.out.println("Usuario nao encontrado. Cadastre o usuario primeiro (opcao 2).");
                return;
            }
            plataforma.tocarPlaylist(ouvinte, playlist);
        } catch (NumberFormatException e) {
            System.out.println("O indice/id precisa ser um numero.");
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Nao foi possivel completar: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("Nao foi possivel tocar: " + e.getMessage());
        }
    }

    private static void listarEpisodios() {
        System.out.print("Apresentador: ");
        plataforma.listarEpisodiosDe(scanner.nextLine());
    }

    private static void exibirReceitaMensal() {
        System.out.println("Receita mensal: R$ " + String.format("%.2f", plataforma.calcularReceitaMensal()));
    }

    // Indice de playlist fora do intervalo tambem e uso indevido: mesma excecao
    // usada por Playlist.getNaPosicao, para caber no mesmo catch acima.
    private static Playlist obterPlaylist(int indice) {
        if (indice < 0 || indice >= playlists.size()) {
            throw new IndexOutOfBoundsException(
                    "indice de playlist " + indice + " nao existe (ha " + playlists.size() + " playlist(s)).");
        }
        return playlists.get(indice);
    }
}
