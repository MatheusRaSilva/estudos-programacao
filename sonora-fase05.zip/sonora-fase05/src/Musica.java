public class Musica extends Conteudo {

    private final String artista;

    public Musica(String titulo, String artista, int duracaoSegundos) {
        // O artista e validado ANTES do super() (que gasta um id), para que uma
        // tentativa invalida continue sem deixar buraco na sequencia de ids.
        super(titulo, duracaoAposValidarArtista(artista, duracaoSegundos));
        this.artista = artista;
    }

    private static int duracaoAposValidarArtista(String artista, int duracaoSegundos) {
        exigirTexto(artista, "Artista invalido: nao pode ser vazio.");
        return duracaoSegundos;
    }

    public String getArtista() {
        return artista;
    }

    @Override
    public String getCreditos() {
        return artista;
    }
}
