public class PlanoGratuito extends Plano {

    public PlanoGratuito() {
        super("Gratuito");
    }

    @Override
    public double calcularMensalidade() {
        return 0.0;
    }

    @Override
    public boolean temAnuncios() {
        return true;
    }
}
