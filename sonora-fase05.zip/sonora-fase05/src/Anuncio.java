// Anuncio nao herda de Conteudo nem de Plano: ele "toca como um conteudo"
// (Reproduzivel) e "gera receita como um plano" (Faturavel), via interfaces.
public class Anuncio implements Faturavel, Reproduzivel {

    private final String anunciante;
    private final String titulo;
    private final int duracaoSegundos;
    private final double valorPorMilImpressoes;
    private int impressoes;

    public Anuncio(String anunciante, String titulo, int duracaoSegundos, double valorPorMilImpressoes) {
        if (anunciante == null || anunciante.trim().isEmpty()) {
            throw new IllegalArgumentException("Anunciante invalido: nao pode ser vazio.");
        }
        if (titulo == null || titulo.trim().isEmpty()) {
            throw new IllegalArgumentException("Titulo invalido: nao pode ser vazio.");
        }
        if (duracaoSegundos <= 0) {
            throw new IllegalArgumentException(
                    "Duracao invalida: " + duracaoSegundos + ". A duracao deve ser maior que zero.");
        }
        if (valorPorMilImpressoes <= 0) {
            throw new IllegalArgumentException(
                    "Valor por mil impressoes invalido: " + valorPorMilImpressoes + ". Deve ser maior que zero.");
        }
        this.anunciante = anunciante;
        this.titulo = titulo;
        this.duracaoSegundos = duracaoSegundos;
        this.valorPorMilImpressoes = valorPorMilImpressoes;
        this.impressoes = 0;
    }

    public String getAnunciante() {
        return anunciante;
    }

    public String getTitulo() {
        return titulo;
    }

    @Override
    public int getDuracaoSegundos() {
        return duracaoSegundos;
    }

    public double getValorPorMilImpressoes() {
        return valorPorMilImpressoes;
    }

    public int getImpressoes() {
        return impressoes;
    }

    @Override
    public void reproduzir() {
        impressoes++;
        System.out.println("[Anuncio] " + titulo + " - oferecimento de " + anunciante);
    }

    // O que o anunciante paga no mes (antigo calcularValorVeiculacao).
    @Override
    public double calcularMensalidade() {
        return impressoes / 1000.0 * valorPorMilImpressoes;
    }
}
