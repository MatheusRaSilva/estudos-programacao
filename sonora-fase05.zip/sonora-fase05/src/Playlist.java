import java.util.ArrayList;

public class Playlist {

    private static final int CAPACIDADE_MAXIMA = 100;

    private String nome;
    private Usuario dono;
    private ArrayList<Conteudo> conteudos;

    public Playlist(String nome, Usuario dono) {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome da playlist invalido: nao pode ser vazio.");
        }
        if (dono == null) {
            throw new IllegalArgumentException("Playlist precisa de um dono (Usuario nulo).");
        }
        this.nome = nome;
        this.dono = dono;
        this.conteudos = new ArrayList<Conteudo>();
    }

    public String getNome() {
        return nome;
    }

    public Usuario getDono() {
        return dono;
    }

    // A contagem manual saiu de cena: quem responde isso agora e o size() da lista.
    public int getQuantidade() {
        return conteudos.size();
    }

    public boolean adicionar(Conteudo conteudo) {
        if (conteudo == null) {
            // Passar conteudo nulo e uso indevido do metodo: vira excecao.
            throw new IllegalArgumentException("Nao e possivel adicionar um conteudo nulo.");
        }
        if (conteudos.size() >= CAPACIDADE_MAXIMA) {
            // Playlist cheia e um estado normal e previsto: continua sinalizado por retorno.
            return false;
        }
        conteudos.add(conteudo);
        return true;
    }

    public Conteudo getNaPosicao(int indice) {
        if (indice < 0 || indice >= conteudos.size()) {
            // Pedir uma posicao fora do intervalo e uso indevido de quem chamou.
            throw new IndexOutOfBoundsException(
                    "Posicao invalida: " + indice + ". A playlist tem " + conteudos.size() + " item(ns).");
        }
        return conteudos.get(indice);
    }

    public boolean removerNaPosicao(int indice) {
        if (indice < 0 || indice >= conteudos.size()) {
            throw new IndexOutOfBoundsException(
                    "Posicao invalida: " + indice + ". A playlist tem " + conteudos.size() + " item(ns).");
        }
        // O remove() do ArrayList ja reorganiza a lista sozinho, sem deixar buraco.
        conteudos.remove(indice);
        return true;
    }

    public int getDuracaoTotalSegundos() {
        int total = 0;
        for (Conteudo conteudo : conteudos) {
            total += conteudo.getDuracaoSegundos();
        }
        return total;
    }

    public void reproduzirTudo() {
        for (Conteudo conteudo : conteudos) {
            conteudo.reproduzir();
        }
    }
}
