public abstract class Conteudo implements Reproduzivel {

    private static int contadorId = 0;

    private final int id;
    private final String titulo;
    private final int duracaoSegundos;
    private int reproducoes;

    protected Conteudo(String titulo, int duracaoSegundos) {
        if (titulo == null || titulo.trim().isEmpty()) {
            throw new IllegalArgumentException("Titulo invalido: nao pode ser vazio.");
        }
        if (duracaoSegundos <= 0) {
            throw new IllegalArgumentException(
                    "Duracao invalida: " + duracaoSegundos + ". A duracao deve ser maior que zero.");
        }
        // So gera o id (e "gasta" um numero do contador) depois que tudo foi validado,
        // senao uma tentativa invalida deixaria buraco na sequencia de ids.
        contadorId++;
        this.id = contadorId;
        this.titulo = titulo;
        this.duracaoSegundos = duracaoSegundos;
        this.reproducoes = 0;
    }

    // Texto simples validado, usado pelas subclasses (artista, apresentador).
    protected static void exigirTexto(String valor, String mensagem) {
        if (valor == null || valor.trim().isEmpty()) {
            throw new IllegalArgumentException(mensagem);
        }
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    @Override
    public int getDuracaoSegundos() {
        return duracaoSegundos;
    }

    public int getReproducoes() {
        return reproducoes;
    }

    // Quem decide qual getCreditos() roda aqui e o tipo dinamico do objeto.
    @Override
    public final void reproduzir() {
        reproducoes++;
        System.out.println("Tocando: " + titulo + " - " + getCreditos());
    }

    public abstract String getCreditos();

    @Override
    public String toString() {
        return "#" + id + " - " + titulo + " - " + getCreditos() + " (" + getDuracaoFormatada()
                + ") - " + reproducoes + " reproducoes";
    }
}
