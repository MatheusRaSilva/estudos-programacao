# Sonora - Fase 05 - Polimorfismo e interfaces

Continuação da Fase 04.

## Estrutura

```
sonora-fase05/
├── docs/
│   ├── diagrama-classes.png   <- Parte A: diagrama atualizado
│   ├── diagrama-classes.svg   <- fonte editável
│   └── modelagem.md           <- justificativa das associações e interfaces
├── planos-de-teste.md
├── src/   App, Plataforma, Playlist, Usuario,
│          Conteudo (abstrata), Musica, Podcast,
│          Plano (abstrata), PlanoGratuito, PlanoPremium, Anuncio,
│          Cronometravel, Reproduzivel, Faturavel (interfaces)
└── test/  testes JUnit (herdados da Fase 03)
```

## O que foi feito

- **B1.** `Playlist` e `Plataforma` guardam `ArrayList<Conteudo>`; `getDuracaoTotalSegundos()`
  e `reproduzirTudo()` funcionam com músicas e podcasts misturados, sem `if` de tipo.
- **B2.** `Plataforma.calcularReceitaMensal()`.
- **B3.** Tipo estático x dinâmico comentado no `main` do `App`; `getApresentador()`
  comentado com a explicação; `Plataforma.listarEpisodiosDe(String)` usa `instanceof` + cast.
- **C1/C3/C4.** `Anuncio` (sem herdar de `Conteudo` nem de `Plano`), `Faturavel`,
  `Cronometravel` (com `default`), `Reproduzivel extends Cronometravel`; `Plano` implementa
  `Faturavel` sem implementar o método; `Anuncio` implementa `Faturavel` e `Reproduzivel`.
- **D1.** `calcularReceitaMensal()` monta um `ArrayList<Faturavel>` e soma em um único laço.
- **D2.** `Plataforma.tocarPlaylist(ouvinte, playlist)`: fila `ArrayList<Reproduzivel>`,
  anúncio após cada 2 itens em rodízio quando `temAnuncios()` e há anúncio cadastrado.
- **D3.** Menu: 13 cadastrar anúncio, 14 adicionar podcast a uma playlist, 15 tocar playlist
  para um usuário, 16 listar episódios de um apresentador, 17 receita mensal.

## Demonstração (receita antes e depois)

1. Opção 2: cadastre um usuário no plano **Gratuito** (id 1) e outro no **Premium** (id 2).
2. Opção 13: cadastre um ou dois anúncios.
3. Opção 3: crie uma playlist (ids 1, 2, 4, 5 = músicas e podcasts do acervo inicial).
4. Opção 17: receita mensal (só a mensalidade do Premium).
5. Opção 15: toque a playlist (índice 0) para o usuário 1 (Gratuito) — aparecem anúncios.
6. Opção 17 de novo: a receita sobe com as impressões dos anúncios.
   Tocar para o usuário Premium não intercala anúncios nem muda a receita.

## Como rodar

```bash
javac -d out src/*.java
java -cp out App
```

Testes (precisam do `junit-platform-console-standalone` salvo como `junit-console.jar`):

```bash
javac -d out -cp junit-console.jar src/*.java test/*.java
java -jar junit-console.jar execute --class-path out --scan-class-path
```
