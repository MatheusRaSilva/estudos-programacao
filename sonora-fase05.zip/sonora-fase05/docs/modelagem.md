# Sonora - Fase 05 - Parte A: modelagem dos relacionamentos

Diagrama: `docs/diagrama-classes.png` (fonte editável em `docs/diagrama-classes.svg`).

Abaixo, cada associação com os quatro adornos e a justificativa da multiplicidade
e da navegabilidade.

---

## 1. Plataforma —— Conteudo (o acervo)

| Adorno | Valor |
|---|---|
| Nome | `Plataforma cadastra Conteudo` (leitura da Plataforma para o Conteudo) |
| Papéis | `- plataforma` (lado Plataforma), `- acervo` (lado Conteudo) |
| Multiplicidade | Plataforma `1` —— `0..*` Conteudo |
| Navegabilidade | Unidirecional: Plataforma → Conteudo |

**Multiplicidade.** Do lado Conteudo é `0..*` (músicas e podcasts na mesma coleção) porque uma plataforma recém-criada
começa com o acervo vazio (pode não haver nenhuma música) e depois cresce sem
limite conceitual. Do lado Plataforma é `1` porque, no Sonora, uma música
cadastrada pertence ao acervo de exatamente uma plataforma — ela só existe no
sistema depois de ser cadastrada em uma.

**Navegabilidade.** É unidirecional porque só a Plataforma guarda a referência:
ela tem `ArrayList<Conteudo> acervo` e consegue chegar aos conteúdos (por exemplo em
`buscarMusica`). A classe `Conteudo` não tem nenhum atributo apontando de volta
para a Plataforma, então não é possível caminhar de um conteúdo até a plataforma.

---

## 2. Plataforma —— Usuario (os registrados)

| Adorno | Valor |
|---|---|
| Nome | `Plataforma registra Usuario` (leitura da Plataforma para o Usuario) |
| Papéis | `- plataforma` (lado Plataforma), `- registrados` (lado Usuario) |
| Multiplicidade | Plataforma `1` —— `0..*` Usuario |
| Navegabilidade | Unidirecional: Plataforma → Usuario |

**Multiplicidade.** `0..*` do lado Usuario pelo mesmo motivo do acervo: a
plataforma pode não ter nenhum usuário registrado ainda e passa a ter muitos.
`1` do lado Plataforma porque um usuário está registrado em uma única plataforma.

**Navegabilidade.** Unidirecional pelo mesmo padrão do item 1: a Plataforma
possui `ArrayList<Usuario> usuarios` e percorre essa lista em
`buscarUsuarioPorId`, mas `Usuario` não conhece a plataforma em que foi
registrado.

---

## 3. Usuario —— Playlist (o dono)

| Adorno | Valor |
|---|---|
| Nome | `Usuario cria Playlist` (leitura do Usuario para a Playlist) |
| Papéis | `- dono` (lado Usuario), `- playlists` (lado Playlist) |
| Multiplicidade | Playlist `0..*` —— `1` Usuario |
| Navegabilidade | Unidirecional: Playlist → Usuario |

**Multiplicidade.** Do lado Usuario é `1` (exatamente um) porque o construtor
de `Playlist` recusa dono nulo — toda playlist nasce obrigatoriamente com um
dono, e só um. Do lado Playlist é `0..*` porque um usuário pode não ter criado
nenhuma playlist ou ter criado várias.

**Navegabilidade.** Unidirecional da Playlist para o Usuario: é a `Playlist`
que guarda o atributo `dono` e expõe `getDono()`. O `Usuario` não mantém uma
lista das playlists que criou, então não dá para partir de um usuário e chegar
às suas playlists. Note que a direção de leitura do nome (`Usuario cria
Playlist`) é o contrário da direção de navegação — os dois adornos são
independentes.

---

## 4. Usuario —— Usuario (associação reflexiva: seguir)

| Adorno | Valor |
|---|---|
| Nome | `Usuario segue Usuario` |
| Papéis | `- seguidores` (ponta de origem), `- seguindo` (ponta de destino) |
| Multiplicidade | `0..*` —— `0..*` |
| Navegabilidade | Unidirecional: no sentido do papel `- seguindo` |

**Multiplicidade.** `0..*` nas duas pontas: um usuário pode não seguir ninguém
ou seguir vários (`- seguindo`), e pode não ter nenhum seguidor ou ter vários
(`- seguidores`). Não há mínimo obrigatório em nenhum dos lados, por isso `0..*`
e não `1..*`.

**Navegabilidade.** Unidirecional porque o `Usuario` guarda apenas
`ArrayList<Usuario> seguindo`. Dá para partir de um usuário e listar quem ele
segue, mas não existe uma lista de seguidores — para descobrir quem segue um
usuário seria preciso varrer todos os outros. Os dois papéis precisam ser
nomeados justamente porque a mesma classe aparece nas duas pontas: sem eles não
dá para saber qual ponta é o seguidor e qual é o seguido.

---

## 5. Playlist —— Conteudo (exemplo da fase anterior, agora apontando para Conteudo)

| Adorno | Valor |
|---|---|
| Nome | `Playlist contem Conteudo` (leitura da Playlist para o Conteudo) |
| Papéis | `- playlists` (lado Playlist), `- itens` (lado Conteudo) |
| Multiplicidade | Playlist `0..*` —— `0..100` Conteudo |
| Navegabilidade | Unidirecional: Playlist → Conteudo |

**Multiplicidade.** Do lado Conteudo é `0..100` (um caso de `m..n`): a playlist
pode estar vazia e a constante `CAPACIDADE_MAXIMA` limita em 100 faixas. Do lado
Playlist é `0..*` porque o mesmo conteúdo pode aparecer em quantas playlists
quiser — ou em nenhuma.

**Navegabilidade.** Unidirecional: a `Playlist` tem `ArrayList<Conteudo> conteudos`
e devolve itens em `getNaPosicao`, enquanto o `Conteudo` não sabe em quais
playlists está.

---

## 6. Plataforma —— Anuncio (nova)

| Adorno | Valor |
|---|---|
| Nome | `Plataforma veicula Anuncio` (leitura da Plataforma para o Anuncio) |
| Papéis | `- plataforma` (lado Plataforma), `- anuncios` (lado Anuncio) |
| Multiplicidade | Plataforma `1` —— `0..*` Anuncio |
| Navegabilidade | Unidirecional: Plataforma → Anuncio |

**Multiplicidade.** `0..*` do lado Anuncio: a plataforma pode não ter nenhum anúncio
cadastrado (e então `tocarPlaylist` simplesmente não intercala nada) ou ter vários.
`1` do lado Plataforma: o anúncio é veiculado por uma única plataforma.

**Navegabilidade.** Unidirecional: só a Plataforma guarda `ArrayList<Anuncio> anuncios`.
O `Anuncio` não conhece a plataforma.

---

## 7. Usuario —— Plano (necessária para a receita)

| Adorno | Valor |
|---|---|
| Nome | `Usuario possui Plano` |
| Papéis | `- assinante` (lado Usuario), `- plano` (lado Plano) |
| Multiplicidade | Usuario `1` —— `1` Plano |
| Navegabilidade | Unidirecional: Usuario → Plano |

O `Usuario` guarda o atributo `plano` (e expõe `getPlano()`); é por ele que a
Plataforma chega às mensalidades em `calcularReceitaMensal()`. Cada usuário tem
exatamente um plano, e o plano não conhece o usuário.

---

## 8. Interfaces, herança entre interfaces e realizações

| Elemento | No diagrama |
|---|---|
| `Cronometravel` | `<<interface>>`: `getDuracaoSegundos()` e o método `default` `getDuracaoFormatada()` |
| `Reproduzivel` | `<<interface>>` que **herda** de `Cronometravel` (linha cheia, triângulo vazado) e acrescenta `reproduzir()` |
| `Faturavel` | `<<interface>>` com `calcularMensalidade()` |
| `Conteudo` (abstrata) | realiza `Reproduzivel` — `Musica` e `Podcast` herdam de `Conteudo` |
| `Anuncio` | realiza `Faturavel` **e** `Reproduzivel` (sem herdar de `Conteudo` nem de `Plano`) |
| `Plano` (abstrata) | realiza `Faturavel` sem implementar o método; `PlanoGratuito` e `PlanoPremium` herdam de `Plano` |

Realização é a linha **tracejada** com triângulo vazado apontando para a interface.
