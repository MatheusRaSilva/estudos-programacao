# Sonora - Fase 03 - Planos de teste

Cada plano abaixo vira, na Parte 2, uma classe de teste em JUnit 6, com um método `@Test`
por caso (o texto da coluna **Descrição** é usado como `@DisplayName`).

---

## Plano de testes PL01 - Validar `Musica.getDuracaoFormatada()`

*(fornecido pelo professor; na Fase 05 o formato passou a ser o do método `default` de `Cronometravel`: minutos sem zero à esquerda)*

| Caso | Descrição | Entrada | Saída esperada |
|---|---|---|---|
| 1 | Duração com minutos e segundos | Música de 125 segundos | Deve resultar em "2:05" |
| 2 | Duração redonda em minutos | Música de 90 segundos | Deve resultar em "1:30" |
| 3 | Menos de um minuto (segundos com zero à esquerda) | Música de 5 segundos | Deve resultar em "0:05" |
| 4 | Dois dígitos nos minutos | Música de 600 segundos | Deve resultar em "10:00" |
| 5 | Valor logo abaixo de dez minutos | Música de 599 segundos | Deve resultar em "9:59" |

---

## Plano de testes PL02 - Validar construtor de `Musica` com dados inválidos

*(fornecido pelo professor, usado como referência)*

| Caso | Descrição | Entrada | Saída esperada |
|---|---|---|---|
| 1 | Título vazio deve ser rejeitado | título "", artista "Queen", duração 355 | Deve lançar IllegalArgumentException |
| 2 | Título nulo deve ser rejeitado | título null, artista "Queen", duração 355 | Deve lançar IllegalArgumentException |
| 3 | Artista vazio deve ser rejeitado | título "Bohemian Rhapsody", artista "", duração 355 | Deve lançar IllegalArgumentException |
| 4 | Duração zero deve ser rejeitada | título válido, artista válido, duração 0 | Deve lançar IllegalArgumentException |
| 5 | Duração negativa deve ser rejeitada | título válido, artista válido, duração -10 | Deve lançar IllegalArgumentException |
| 6 | Dados válidos criam a música | título "Bohemian Rhapsody", artista "Queen", duração 355 | Objeto criado, com id maior que zero |

---

## Plano de testes PL03 - `Playlist.adicionar(musica)`

| Caso | Descrição | Entrada | Saída esperada |
|---|---|---|---|
| 1 | Adicionar música em playlist com espaço | Playlist vazia; `adicionar(musica)` com uma música válida | Retorna `true`; `getQuantidade()` passa de 0 para 1 |
| 2 | Adicionar quando a playlist já está cheia | Playlist com 100 músicas (capacidade máxima); `adicionar(musica)` com mais uma música | Retorna `false`; `getQuantidade()` continua 100 |
| 3 | Adicionar música nula | Playlist vazia; `adicionar(null)` | Lança IllegalArgumentException |

---

## Plano de testes PL04 - `Playlist.getNaPosicao(indice)`

| Caso | Descrição | Entrada | Saída esperada |
|---|---|---|---|
| 1 | Posição válida devolve a música certa | Playlist com 3 músicas; `getNaPosicao(1)` | Retorna exatamente a música que foi adicionada na posição 1 |
| 2 | Índice negativo | Playlist com 3 músicas; `getNaPosicao(-1)` | Lança IndexOutOfBoundsException |
| 3 | Índice além da quantidade | Playlist com 3 músicas; `getNaPosicao(3)` | Lança IndexOutOfBoundsException |

---

## Plano de testes PL05 - `Playlist.removerNaPosicao(indice)`

| Caso | Descrição | Entrada | Saída esperada |
|---|---|---|---|
| 1 | Remover posição válida reorganiza sem deixar buraco | Playlist com 3 músicas (posições 0, 1, 2); `removerNaPosicao(0)` | `getQuantidade()` passa para 2; a música que estava na posição 1 passa a ocupar a posição 0 |
| 2 | Índice negativo | Playlist com 3 músicas; `removerNaPosicao(-1)` | Lança IndexOutOfBoundsException |
| 3 | Índice além da quantidade | Playlist com 3 músicas; `removerNaPosicao(3)` | Lança IndexOutOfBoundsException |

---

## Plano de testes PL06 - `Plataforma.buscarMusica(titulo)` e `buscarMusicaPorId(id)`

| Caso | Descrição | Entrada | Saída esperada |
|---|---|---|---|
| 1 | Buscar por título de música cadastrada | Plataforma com "Bohemian Rhapsody" cadastrada; `buscarMusica("Bohemian Rhapsody")` | Retorna o objeto `Musica` correspondente |
| 2 | Buscar por id de música cadastrada | Plataforma com música cadastrada; `buscarMusicaPorId(id)` com o id dessa música | Retorna o objeto `Musica` correspondente |
| 3 | Buscar por título inexistente | Plataforma com músicas cadastradas; `buscarMusica("Musica Que Nao Existe")` | Retorna `null` |
| 4 | Buscar por id inexistente | Plataforma com músicas cadastradas; `buscarMusicaPorId(-1)` | Retorna `null` |

---

## Plano de testes PL07 - `Musica.reproduzir()`

| Caso | Descrição | Entrada | Saída esperada |
|---|---|---|---|
| 1 | Música recém-criada começa com zero reproduções | Música nova, sem chamar `reproduzir()` | `getReproducoes()` retorna 0 |
| 2 | Uma chamada aumenta o contador em um | Música nova; chamar `reproduzir()` uma vez | `getReproducoes()` retorna 1 |
| 3 | Múltiplas chamadas aumentam o contador conforme o número de chamadas | Música nova; chamar `reproduzir()` três vezes | `getReproducoes()` retorna 3 |

---

## Plano de testes PL08 (bônus) - Contadores de id

| Caso | Descrição | Entrada | Saída esperada |
|---|---|---|---|
| 1 | Ids de Música saem sequenciais | Criar 3 músicas em sequência | id da 2ª = id da 1ª + 1; id da 3ª = id da 2ª + 1 |
| 2 | Ids de Usuário saem sequenciais | Criar 3 usuários em sequência | id do 2º = id do 1º + 1; id do 3º = id do 2º + 1 |
| 3 | Contadores de Música e Usuário são independentes | Criar 1 usuário, depois 1 música, depois outro usuário (intercalando) | O id do 2º usuário = id do 1º usuário + 1, mesmo com a música criada no meio (a criação da música não consome o contador de Usuario) |

> Observação sobre PL08: como `contadorId` é `static`, o valor absoluto do primeiro id
> depende de quantos objetos já foram criados antes em outros testes da mesma execução.
> Por isso os casos verificam a **sequência relativa** (diferença entre ids), e não um
> valor absoluto fixo como "1, 2, 3".
