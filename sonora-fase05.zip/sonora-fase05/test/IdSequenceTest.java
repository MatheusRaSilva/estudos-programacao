import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class IdSequenceTest {

    // ---------------------------------------------------------------
    // PL08 (bônus) - Contadores de id
    //
    // Como contadorId e static em Musica e em Usuario, o valor absoluto do
    // primeiro id depende de quantos objetos ja foram criados antes, em
    // outros testes da mesma execucao. Por isso os casos abaixo verificam a
    // SEQUENCIA RELATIVA (diferenca entre ids), e nao um valor absoluto fixo.
    // ---------------------------------------------------------------

    @Test
    @DisplayName("Ids de Música saem sequenciais")
    void pl08Caso1_idsDeMusicaSaemSequenciais() {
        Musica m1 = new Musica("Musica 1", "Artista", 100);
        Musica m2 = new Musica("Musica 2", "Artista", 100);
        Musica m3 = new Musica("Musica 3", "Artista", 100);

        assertEquals(m1.getId() + 1, m2.getId());
        assertEquals(m2.getId() + 1, m3.getId());
    }

    @Test
    @DisplayName("Ids de Usuário saem sequenciais")
    void pl08Caso2_idsDeUsuarioSaemSequenciais() {
        Usuario u1 = new Usuario("Usuario 1", "u1@example.com");
        Usuario u2 = new Usuario("Usuario 2", "u2@example.com");
        Usuario u3 = new Usuario("Usuario 3", "u3@example.com");

        assertEquals(u1.getId() + 1, u2.getId());
        assertEquals(u2.getId() + 1, u3.getId());
    }

    @Test
    @DisplayName("Contadores de Música e Usuário são independentes")
    void pl08Caso3_contadoresDeMusicaEUsuarioSaoIndependentes() {
        Usuario u1 = new Usuario("Usuario 1", "u1@example.com");
        Musica musicaNoMeio = new Musica("Musica no meio", "Artista", 100);
        Usuario u2 = new Usuario("Usuario 2", "u2@example.com");

        // A criacao da musica entre u1 e u2 nao pode "roubar" um numero
        // do contador de Usuario: u2 continua sendo exatamente u1 + 1.
        assertEquals(u1.getId() + 1, u2.getId());
        assertNotNull(musicaNoMeio);
    }
}
