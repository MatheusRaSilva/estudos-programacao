import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PlataformaTest {

    // Cenario base que se repete: uma Plataforma ja com algumas musicas cadastradas
    // e um usuario cadastrado.
    private Plataforma plataforma;
    private Musica bohemianRhapsody;

    @BeforeEach
    void setUp() {
        plataforma = new Plataforma();

        bohemianRhapsody = new Musica("Bohemian Rhapsody", "Queen", 354);
        plataforma.cadastrarConteudo(bohemianRhapsody);
        plataforma.cadastrarConteudo(new Musica("Blowin' in the Wind", "Bob Dylan", 65));
        plataforma.cadastrarConteudo(new Musica("Aguas de Marco", "Elis Regina", 600));

        plataforma.cadastrarUsuario(new Usuario("Ana", "ana@example.com"));
    }

    // ---------------------------------------------------------------
    // PL06 - Plataforma.buscarMusica(titulo) e buscarMusicaPorId(id)
    // ---------------------------------------------------------------

    @Test
    @DisplayName("Buscar por título de música cadastrada")
    void pl06Caso1_buscarPorTituloDeMusicaCadastrada() {
        Conteudo encontrada = plataforma.buscarMusica("Bohemian Rhapsody");
        assertEquals(bohemianRhapsody, encontrada);
    }

    @Test
    @DisplayName("Buscar por id de música cadastrada")
    void pl06Caso2_buscarPorIdDeMusicaCadastrada() {
        Conteudo encontrada = plataforma.buscarMusicaPorId(bohemianRhapsody.getId());
        assertEquals(bohemianRhapsody, encontrada);
    }

    @Test
    @DisplayName("Buscar por título inexistente")
    void pl06Caso3_buscarPorTituloInexistente() {
        Conteudo encontrada = plataforma.buscarMusica("Musica Que Nao Existe");
        assertNull(encontrada);
    }

    @Test
    @DisplayName("Buscar por id inexistente")
    void pl06Caso4_buscarPorIdInexistente() {
        Conteudo encontrada = plataforma.buscarMusicaPorId(-1);
        assertNull(encontrada);
    }
}
