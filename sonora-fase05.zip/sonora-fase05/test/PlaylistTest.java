import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PlaylistTest {

    // Cenario base que se repete em varios casos: uma playlist com dono e
    // 3 musicas ja adicionadas nas posicoes 0, 1 e 2.
    private Usuario dono;
    private Playlist playlist;
    private Musica musica0;
    private Musica musica1;
    private Musica musica2;

    @BeforeEach
    void setUp() {
        dono = new Usuario("Ana", "ana@example.com");
        playlist = new Playlist("Favoritas", dono);

        musica0 = new Musica("Bohemian Rhapsody", "Queen", 354);
        musica1 = new Musica("Blowin' in the Wind", "Bob Dylan", 65);
        musica2 = new Musica("Aguas de Marco", "Elis Regina", 600);

        playlist.adicionar(musica0);
        playlist.adicionar(musica1);
        playlist.adicionar(musica2);
    }

    // ---------------------------------------------------------------
    // PL03 - Playlist.adicionar(musica)
    // ---------------------------------------------------------------

    @Test
    @DisplayName("Adicionar música em playlist com espaço")
    void pl03Caso1_adicionarEmPlaylistComEspaco() {
        Playlist vazia = new Playlist("Nova playlist", dono);
        Musica musica = new Musica("Titulo", "Artista", 200);

        boolean resultado = vazia.adicionar(musica);

        assertTrue(resultado);
        assertEquals(1, vazia.getQuantidade());
    }

    @Test
    @DisplayName("Adicionar quando a playlist já está cheia")
    void pl03Caso2_adicionarQuandoPlaylistJaEstaCheia() {
        Playlist cheia = new Playlist("Cheia", dono);
        int capacidadeMaxima = 100;
        for (int i = 0; i < capacidadeMaxima; i++) {
            cheia.adicionar(new Musica("Musica " + i, "Artista " + i, 100));
        }

        boolean resultado = cheia.adicionar(new Musica("Extra", "Artista Extra", 100));

        assertFalse(resultado);
        assertEquals(capacidadeMaxima, cheia.getQuantidade());
    }

    @Test
    @DisplayName("Adicionar música nula")
    void pl03Caso3_adicionarMusicaNula() {
        Playlist vazia = new Playlist("Nova playlist", dono);
        assertThrows(IllegalArgumentException.class, () -> vazia.adicionar(null));
    }

    // ---------------------------------------------------------------
    // PL04 - Playlist.getNaPosicao(indice)
    // ---------------------------------------------------------------

    @Test
    @DisplayName("Posição válida devolve a música certa")
    void pl04Caso1_posicaoValidaDevolveAMusicaCerta() {
        assertEquals(musica1, playlist.getNaPosicao(1));
    }

    @Test
    @DisplayName("Índice negativo")
    void pl04Caso2_indiceNegativo() {
        assertThrows(IndexOutOfBoundsException.class, () -> playlist.getNaPosicao(-1));
    }

    @Test
    @DisplayName("Índice além da quantidade")
    void pl04Caso3_indiceAlemDaQuantidade() {
        assertThrows(IndexOutOfBoundsException.class, () -> playlist.getNaPosicao(3));
    }

    // ---------------------------------------------------------------
    // PL05 - Playlist.removerNaPosicao(indice)
    // ---------------------------------------------------------------

    @Test
    @DisplayName("Remover posição válida reorganiza sem deixar buraco")
    void pl05Caso1_removerPosicaoValidaReorganizaSemDeixarBuraco() {
        playlist.removerNaPosicao(0);

        assertEquals(2, playlist.getQuantidade());
        assertEquals(musica1, playlist.getNaPosicao(0));
        assertEquals(musica2, playlist.getNaPosicao(1));
    }

    @Test
    @DisplayName("Índice negativo")
    void pl05Caso2_indiceNegativo() {
        assertThrows(IndexOutOfBoundsException.class, () -> playlist.removerNaPosicao(-1));
    }

    @Test
    @DisplayName("Índice além da quantidade")
    void pl05Caso3_indiceAlemDaQuantidade() {
        assertThrows(IndexOutOfBoundsException.class, () -> playlist.removerNaPosicao(3));
    }
}
