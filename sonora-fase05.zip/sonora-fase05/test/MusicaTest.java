import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MusicaTest {

    // Cenario base que se repete em varios casos: uma musica valida, ja criada.
    private Musica musica;

    @BeforeEach
    void setUp() {
        musica = new Musica("Bohemian Rhapsody", "Queen", 355);
    }

    // ---------------------------------------------------------------
    // PL01 - Validar Musica.getDuracaoFormatada()
    // ---------------------------------------------------------------

    @Test
    @DisplayName("Duração com minutos e segundos")
    void pl01Caso1_duracaoComMinutosESegundos() {
        Musica m = new Musica("Titulo", "Artista", 125);
        assertEquals("2:05", m.getDuracaoFormatada());
    }

    @Test
    @DisplayName("Duração redonda em minutos")
    void pl01Caso2_duracaoRedondaEmMinutos() {
        Musica m = new Musica("Titulo", "Artista", 90);
        assertEquals("1:30", m.getDuracaoFormatada());
    }

    @Test
    @DisplayName("Menos de um minuto, com zero a esquerda")
    void pl01Caso3_menosDeUmMinutoComZeroAEsquerda() {
        Musica m = new Musica("Titulo", "Artista", 5);
        assertEquals("0:05", m.getDuracaoFormatada());
    }

    @Test
    @DisplayName("Dois dígitos nos minutos")
    void pl01Caso4_doisDigitosNosMinutos() {
        Musica m = new Musica("Titulo", "Artista", 600);
        assertEquals("10:00", m.getDuracaoFormatada());
    }

    @Test
    @DisplayName("Valor logo abaixo de dez minutos")
    void pl01Caso5_valorLogoAbaixoDeDezMinutos() {
        Musica m = new Musica("Titulo", "Artista", 599);
        assertEquals("9:59", m.getDuracaoFormatada());
    }

    // ---------------------------------------------------------------
    // PL02 - Validar construtor de Musica com dados invalidos
    // ---------------------------------------------------------------

    @Test
    @DisplayName("Título vazio deve ser rejeitado")
    void pl02Caso1_tituloVazioDeveSerRejeitado() {
        assertThrows(IllegalArgumentException.class,
                () -> new Musica("", "Queen", 355));
    }

    @Test
    @DisplayName("Título nulo deve ser rejeitado")
    void pl02Caso2_tituloNuloDeveSerRejeitado() {
        assertThrows(IllegalArgumentException.class,
                () -> new Musica(null, "Queen", 355));
    }

    @Test
    @DisplayName("Artista vazio deve ser rejeitado")
    void pl02Caso3_artistaVazioDeveSerRejeitado() {
        assertThrows(IllegalArgumentException.class,
                () -> new Musica("Bohemian Rhapsody", "", 355));
    }

    @Test
    @DisplayName("Duração zero deve ser rejeitada")
    void pl02Caso4_duracaoZeroDeveSerRejeitada() {
        assertThrows(IllegalArgumentException.class,
                () -> new Musica("Titulo valido", "Artista valido", 0));
    }

    @Test
    @DisplayName("Duração negativa deve ser rejeitada")
    void pl02Caso5_duracaoNegativaDeveSerRejeitada() {
        assertThrows(IllegalArgumentException.class,
                () -> new Musica("Titulo valido", "Artista valido", -10));
    }

    @Test
    @DisplayName("Dados válidos criam a música")
    void pl02Caso6_dadosValidosCriamAMusica() {
        Musica m = new Musica("Bohemian Rhapsody", "Queen", 355);
        assertNotNull(m);
        assertTrue(m.getId() > 0);
    }

    // ---------------------------------------------------------------
    // PL07 - Musica.reproduzir()
    // ---------------------------------------------------------------

    @Test
    @DisplayName("Música recém-criada começa com zero reproduções")
    void pl07Caso1_musicaNovaComecaComZeroReproducoes() {
        assertEquals(0, musica.getReproducoes());
    }

    @Test
    @DisplayName("Uma chamada aumenta o contador em um")
    void pl07Caso2_umaChamadaAumentaOContadorEmUm() {
        musica.reproduzir();
        assertEquals(1, musica.getReproducoes());
    }

    @Test
    @DisplayName("Múltiplas chamadas aumentam o contador conforme o número de chamadas")
    void pl07Caso3_multiplasChamadasAumentamOContador() {
        musica.reproduzir();
        musica.reproduzir();
        musica.reproduzir();
        assertEquals(3, musica.getReproducoes());
    }
}
